﻿using System;

namespace AkaarInstitute
{
    public partial class IndexVisitor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}