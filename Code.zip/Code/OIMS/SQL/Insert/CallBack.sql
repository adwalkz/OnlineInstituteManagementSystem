insert into CallBack (CallerName, Contact, Reason, Email, Addr) values
(
	'Tiwari',
	'9999999999',
	'General Enq',
	'mail',
	'Laxmi Nagar'
)