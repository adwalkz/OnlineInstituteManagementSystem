insert into Attendance values
(
	'2020-03-23',
	'6 - 7',
	'1018',
	'XI',
	'Batch 1',
	'Maths',
	20250,
	'P'
)