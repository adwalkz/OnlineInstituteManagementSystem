insert into Assignment (UploadDate, Sub, TName, Class, Topic, DownloadLink) values
(
	GETDATE(),
	'Maths',
	'Rajesh Kushwah',
	'XI',
	'vectors',
	'Source/pdf/assignments'
)