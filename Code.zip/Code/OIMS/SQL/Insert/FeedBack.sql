insert into FeedBack values
(
	'Student',
	'202020',
	'Aditya Jain',
	'Good Institute'
)