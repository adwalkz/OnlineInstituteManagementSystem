insert into Leave (UserType, UserID, UserName, FromDate, ToDate, Reason) values
(
	'Teacher',
	1234,
	'Udit',
	'2020-01-01',
	'2020-01-01',
	'New Year'
)