insert into Payment(StudentID, PayDate, PaymentType, OfferApplied, PaidAmount) values (
	'20232',
	GETDATE(),
	'Visa',
	'Null',
	'6000')