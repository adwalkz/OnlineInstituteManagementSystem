insert into Complain (UserType, UserID, UserName, Issue) values
(
	'Student',
	'20200',
	'Aditya Jain',
	'Trouble in Login'
)