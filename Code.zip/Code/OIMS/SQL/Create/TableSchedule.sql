create table Schedule
(
	Class varchar(10) not null,
	Batch varchar(10) not null,
	Sub varchar(10) not null,
	Slot varchar(10) not null
)