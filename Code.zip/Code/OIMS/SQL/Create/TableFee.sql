create table Fee
(
	SubjectID int,
	SubjectName varchar(50) not null,
	SubFee decimal(6,0) not null
)