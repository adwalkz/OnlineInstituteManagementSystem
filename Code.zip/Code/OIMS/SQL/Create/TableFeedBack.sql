create table FeedBack
(
	Date date not null,
	UserType varchar(10) not null,
	UserID int not null,
	UserName varchar(30) not null,
	FeedBack varchar(200) not null
)